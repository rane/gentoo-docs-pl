#!/usr/bin/ruby

# This script is suppoed to be included by main script and defines
# column headers for table of documents and blahblah that comes
# around it

# Running this script alone will check xml conformance with xmllint




# {langfrom} and {langto} are placeholders,
# they will be replaced by languages at runtime
$ColHeaders = [ "Document", \
                "Priorité" ,\
                "Version<br/>{langfrom}" ,\
                "Dernière<br/>modif." ,\
                "Version<br/>{langto}" ,\
                "Dernière<br/>modif." ,\
                "Version {langfrom}<br/>traduite" ,\
                "Diff. entre<br/>versions {langfrom}" ,\
                "Version {langfrom} en<br/>cours de trad." ,\
                "Dernier<br/>traducteur" ]

def ldate
`LC_ALL=fr_FR.utf8 date '+%A %e %B %Y à %H:%M'`.chop
end

$Part1 = <<END_OF_PART_1
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE guide SYSTEM "/dtd/guide.dtd">
<guide lang="fr">

<title>Traduction de la documentation Gentoo en français</title>

<author title="Lead Translator">
  <mail link="neysx@gentoo.org">Xavier Neys</mail>
</author>

<license/>
<version>1.0</version>
<date>#{`date '+%Y-%m-%d'`}</date>

<abstract>
Page de référence des traducteurs de la documentation Gentoo en français
</abstract>

<chapter>
<title>Introduction</title>
<section>
<body>

<p>
Cette page référence la liste des documents Gentoo en cours de traduction ou à
traduire en français.<br/> Celle-ci sera mise à jour régulièrement, c-à-d.
quand un traducteur prend un document en charge et au moins une fois par
semaine.
</p>

<p>
Deux listes sont disponibles :
</p>

<ol>
  <li>
    <uri link="trads-fr.xml">La liste complète</uri>
  </li>
  <li>
    <uri link="trads-fr-0.xml">La liste de fichiers à traduire ou à mettre à jour</uri>
  </li>
</ol>

<note>
Le tableau ci-dessous est généré automatiquement par un <uri
link="http://gentoo.neysx.org/mystuff/trads/doc/trads-doc.xml">script ruby</uri>. 
</note>

</body>
</section>
</chapter>

<chapter>
<title>Explications</title>
<section>
<title>Comment utiliser ce tableau ?</title>
<body>

<p>
Pour chaque document, les informations suivantes sont disponibles :
</p>

<ul>
  <li>
    Le nom du document, ce n'est pas nécessairement le nom du fichier xml
    original.
  </li>
  <li>
    La priorité. Celle-ci est représentée par des pastilles de couleur. Le code
    est le suivant :
    <ul>
      <li><img src="images/green.png"  /> Le document est à jour.</li>
      <li><img src="images/blue.png"   /> Le document est en cours de traduction ou de mise à jour.</li>
      <li><img src="images/yellow.png" /> Le document est d'importance secondaire.</li>
      <li><img src="images/orange.png" /> Le document est important.</li>
      <li><img src="images/red.png"    /> Le document est essentiel.</li>
    </ul>
    Le nombre de pastilles donne une indication sur le retard du document
    traduit par rapport à la version originale. Plus il y a de révisions entre
    la version originale traduite et la version originale actuelle, plus il y a
    de pastilles.
  </li>
  <li>
    Le numéro de version CVS du document original et la date de dernière
    modification. Le numéro pointe vers le document en anglais sur le site
    officiel de Gentoo.
  </li>
  <li>
    Le numéro de version CVS du document traduit et la date de dernière
    modification. Le numéro pointe vers le document en français sur le site
    officiel de Gentoo. Le lien (xml) donne accès au document source utilisé.
    <e>C'est celui-là qui doit être modifié</e> pour actualiser la traduction
    du document.
  </li>
  <li>
    Le numéro de la version originale qui été traduite. Un point
    d'interrogation indique qu'il y a un doute quant à ce numéro, par exemple
    quand le numéro a dû être déduit sur base des dates et des numéros de
    version qui apparaissent dans les documents.
  </li>
  <li>
    Un lien vers les différences entre la la version anglaise qui a été
    traduite et, soit la version anglaise actuelle, soit la version anglaise en
    cours de traduction.
  </li>
  <li>
    Quand un document est en cours de traduction ou de mise à jour, un lien
    vers la version anglaise et son fichier source xml (<e>celui qui doit être
    traduit</e>) sont disponibles. Ceci permet au traducteur de récupérer le
    xml source et de visualiser le document tel qu'il apparaît dans un
    navigateur même si le document original a evolué entre-temps.
  </li>
  <li>
    Le nom du dernier traducteur qui a travaillé sur le document. Les
    différents traducteurs sont mentionnés dans les documents. Le nom est mis
    en <brite>évidence</brite> quand le fichier correspondant n'est plus à jour
    et il devient un lien <b><c>«&#160;mailto&#160;»</c></b> quand le
    traducteur est effectivement en charge de la traduction ou de la mise à
    jour.
  </li>
</ul>
</body>
</section>
</chapter>

<chapter>
<title>Liste des documents</title>
<section>
<body>
<table>
<tcolumn width="100"/>
<tcolumn width="1%"/>
<tcolumn width="12"/>
<tcolumn width="20"/>
<tcolumn width="12"/>
<tcolumn width="20"/>
<tcolumn width="10"/>
<tcolumn width="16"/>
<tcolumn width="10"/>
<tcolumn width="10"/>
END_OF_PART_1

$Part2 = <<END_OF_PART_2
</table></body></section>
</chapter>

<chapter>
<title>Comment contribuer</title>
<section>
<body>

<impo>
Tous nos fichiers utilisent l'encodage UTF-8.<br/>
Si cela vous pose des problèmes, vous pouvez convertir les fichiers dans l'encodage que vous utilisez avec l'utilitaire <c>recode</c> (<b># <c>emerge recode</c></b>).<br/>
Par exemple <c>recode u8..l9 fichier.xml</c> pour convertir en ISO.<br/>
N'oubliez pas de faire l'opération inverse (<c>recode l9..u8 fichier.xml</c>) avant de soumettre votre travail. Merci.
</impo>

<p class="secthead">
Vous pouvez apporter votre contribution à l'effort de documentation de plusieurs façons :
</p>

<ul>
  <li>
    Vous pouvez écrire vous-même une documentation qui vous semble pertinente
    et la soumettre à Gentoo.<br/>
    Vous pouvez la rédiger en anglais ou en français, elle sera ensuite
    traduite dans les autres langues supportées par Gentoo.<br/> 
    Le <uri link="/doc/en/xml-guide.xml">guide XML</uri> (version <uri
    link="/doc/fr/xml-guide.xml">française</uri>) vous est indispensable.
  </li>
  <li>
    Quand vous lisez une documentation et que vous constatez une erreur, une
    faute d'orthographe ou de grammaire, ou autre, soumettez un bug via notre
    interface <uri link="http://bugs.gentoo.org/">bugzilla</uri>.
  </li>
  <li>
    <b>Traduisez</b> vous-même des documents. La marche à suivre est simple :
    <ul>
      <li>
        Vous choisissez un document à traduire ou dont la traduction doit être
        mise à jour et vous le signalez par <mail
        link="neysx@gentoo.org">email</mail> ou de préférence via la <mail
        link="gentoo-doc-fr@gentoo.org">liste de diffusion</mail>. Voyez <uri
        link="/main/en/lists.xml">ici</uri> comment vous inscrire. Vous pouvez
        aussi bavarder avec les traducteurs sur le chan
        #gentoo-doc-fr sur irc.freenode.net.
      </li>
      <li>
        Vous recevez une confirmation dès que possible. Le tableau ci-dessus
        est mis à jour et vous disposez alors des liens vers tous les fichiers
        nécessaires.
      </li>
      <li>
        Une fois votre travail terminé, vous soumettez un bug via <uri
        link="https://bugs.gentoo.org/enter_bug.cgi?product=Doc%20Translations&amp;component=[FR]&amp;short_desc=[fr]%20">ce
        lien vers bugzilla</uri>, ensuite attachez le fichier xml qui contient
        votre traduction. Elle sera relue, validée, éventuellement corrigée et
        ensuite mise en ligne.
      </li>
    </ul>
  </li>
</ul>

<note>
Quand vous soumettez votre traduction, prenez soin de spécifier text/plain
comme type de fichier et pas text/xml.
</note>

<note>
Cette <uri link="trads-fr-conventions.xml">page</uri> explique les conventions
d'usage, donne quelques traductions de termes techniques et rappelle quelques
difficultés de la langue française.
</note>

</body>
</section>
</chapter>
</guide>
END_OF_PART_2

if __FILE__ == $0 then
  require 'open3'
  # Validate document with xmllint
  cmd = "xmllint --noout -;echo $?"
  # Run command through pipe
  pi,po,pe = Open3.popen3(cmd)
  pi.puts $Part1
  pi.puts $Part2
  pi.close
  ro=po.readlines
  re=pe.readlines
  po.close; pe.close
  # display error stream on current stderr
  STDERR.puts re
  raise "\n>>> Invalid xml <<<\n" if ro[0]!~/^0$/  
end
