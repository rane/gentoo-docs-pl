require 'optparse'
require 'ostruct'

class TradsOptionParser
  def self.nick
    ENV["USER"]
  end
  #
  # Return an open structure containing parsed ARGV[]
  #
  def self.parse(args)
    # Define defaults
    options = OpenStruct.new
    options.web     = false
    options.daemon  = false
    options.client  = false
#    options.server  = `uname -n`.chomp
    options.port    = 6764
    options.rport   = nil
    options.webport = 8088
    options.actions = Array.new

    opts = OptionParser.new do |opts|
      opts.banner = "Usage: #{$0} [options] [[--] action [action parameters]]"

      opts.separator ""
      opts.separator "Options:"
      opts.separator ""
      
      opts.on("-h", "--help", "Show this message") do
        puts opts
        exit
      end

      opts.on("-d", "--daemon [port]", "Start daemon, listen on [port] (default is #{options.port})") do |p|
        options.daemon = true
        if p
          raise "Illegal port number" if p !~ /^\d+$/
          options.port = p.to_i
        end
      end

      opts.on("-w", "--web [port]", "Start web interface on [port] (default is #{options.webport})") do |p|
        options.web = true
        if p
          raise "Illegal port number" if p !~ /^\d+$/
          options.webport = p.to_i
        end
      end

      opts.on("-c", "--client [port]", "Connect to daemon that is listening on [port] (default is #{options.port})") do |p|
        options.client = true
        if p
          raise "Illegal port number" if p !~ /^\d+$/
          options.port = p.to_i
        end
#
#         Just in case I allow the daemon to start on anything else than localhost
#
#        if hopo then
#          md = /([^:]*)(:?)(.*)/.match(hopo)
#          if md[2] == ":"
#            # md[1]=host md[3]=port
#            raise "Illegal host name #{md[1]}" if /^[-0-9a-z.]+$/ !~ md[1]
#            raise "Illegal port number #{md[3]}" if /^[0-9]{1,5}$/ !~ md[3]
#            options.server = md[1]
#            options.port   = md[3].to_i
#          else
#            # md[1]=port if it is a valid port number (4 or 5 digits), =hostname otherwise
#            if /^[0-9]{1,5}$/ =~ md[1] then
#              options.port = md[1].to_i
#            else
#              # md[1] should be a valid hostname
#              raise "Illegal host name #{md[1]}" if /^[-0-9a-z.]+$/ !~ md[1]
#              options.server = md[1]
#            end
#          end
#        end
      end
      
      opts.on("-r", "--reverse port", "Have daemon connect back to client using port (nly useful through SSH)") do |p|
        raise "Illegal port number" if p !~ /^\d+$/
        options.rport = p.to_i
      end
      
      opts.separator ""
      opts.separator "Actions (default is to update and upload page):"
      opts.separator ""
      opts.separator "list [filespec]                 List all files matching filespec (default: all files)"
      opts.separator ""
      opts.separator "sync filespec [revision]        Sync all files matching filespec to revision"
      opts.separator "                                (default is latest, use 0 to remove value)"
      opts.separator ""
      opts.separator "diff filespec                   Show log history and diff between current rev and synced rev"
      opts.separator ""
      opts.separator "refresh                         Reload CVS revisions and dates of documents"
      opts.separator ""
      opts.separator "upload                          Generate and upload page"
      opts.separator ""
      opts.separator "lock filespec [nick]            Set lock on all files matching filespec"
      opts.separator "                                in name of nick (default is #{nick})"
      opts.separator ""
      opts.separator "release [filespec] [nick]       Release all files matching filespec that were"
      opts.separator "                                locked by nick (default is all files locked by #{nick})"
      opts.separator "                                When used with one param, it is considered a filespec"
      opts.separator ""
      opts.separator "give [nick] filespec [revision] Define nick as being in charge of files matching filespec"
      opts.separator "                                When used with one param, latest revisions of filespec are given to #{nick}"
      opts.separator "                                When used with two params, latest revisions of filespec are given to nick"
      opts.separator ""
      opts.separator "take filespec [revision]        Synonym of 'give #{nick} filespec [revision]' which feels more natural in English"
      opts.separator ""
      opts.separator "free filespec                   Free document, i.e. remove translator's assignment from filespec"
      opts.separator ""
      opts.separator "group filespec [group]          Make filespec part of group or remove filespec from its group is no group is passed"
      opts.separator ""
    end

    # Parse options
    opts.parse!(args)

    # Known actions
    def self.action?(a)
      action_list=%w[LIST REFRESH UPLOAD SYNC DIFF LOCK RELEASE GIVE TAKE FREE GROUP]
      a.upcase if a and action_list.index(a.upcase)
    end
    
    # Analyse action if any
    while act=ARGV.shift do
      action = OpenStruct.new
      action.action = act.upcase
      case action?(act)
        when nil
          raise "Invalid action (#{act})"
          
        when "LIST"
          action.pattern = if ARGV.first and not action?(ARGV.first)
                             ARGV.shift
                           else
                             '*'
                           end
        when "REFRESH"
          {} #Nothin' to do
          
        when "UPLOAD"
          {} #Nothin' to do
          
        when "SYNC"
          raise "Missing arguments" unless ARGV.first and not action?(ARGV.first)
          action.pattern = ARGV.shift
          action.rev = RevNum.new
          action.rev = RevNum.new(ARGV.shift) if ARGV.first and not action?(ARGV.first)
          
        when "DIFF"
          raise "Missing arguments" unless ARGV.first and not action?(ARGV.first)
          action.pattern = ARGV.shift
          
        when "LOCK"
          raise "Missing arguments" unless ARGV.first and not action?(ARGV.first)
          action.nick = nick #default
          action.pattern = ARGV.shift
          action.nick = ARGV.shift if ARGV.first and not action?(ARGV.first)

        when "RELEASE"
          # Set defaults
          action.nick = nick
          action.pattern = if ARGV.first and not action?(ARGV.first)
                             ARGV.shift
                           else
                             '*'
                           end
          action.nick = ARGV.shift if ARGV.first and not action?(ARGV.first)

        when "GIVE"
          raise "Missing arguments" unless ARGV.first and not action?(ARGV.first)
          # Set defaults
          action.rev = RevNum.new
          action.nick = nick
          p1 = action.pattern = if ARGV.first and not action?(ARGV.first)
                                  ARGV.shift
                                else
                                  '*'
                                end
          p2 = ARGV.shift if ARGV.first and not action?(ARGV.first)
          p3 = ARGV.shift if ARGV.first and not action?(ARGV.first)
          action.nick, action.pattern, action.rev = p1, p2, RevNum.new(p3) if not p2.nil? and not p3.nil?
          action.nick, action.pattern = p1, p2 if not p2.nil? and p3.nil?
        when "TAKE"
          raise "Missing arguments" unless ARGV.first and not action?(ARGV.first)
          # TAKE ... is actually a synonym for GIVE myself ...
          action.action = "GIVE"
          action.nick = nick
          action.pattern = ARGV.shift
          action.rev = if ARGV.first and not action?(ARGV.first)
                         RevNum.new(ARGV.shift)
                       else
                         RevNum.new
                       end
        when "FREE"
          action.pattern = if ARGV.first and not action?(ARGV.first)
                             ARGV.shift
                           else
                             '*'
                           end
        when "GROUP"
          raise "Missing arguments" unless ARGV.first and not action?(ARGV.first)
          action.pattern = ARGV.shift
          action.group = ARGV.shift if ARGV.first and not action?(ARGV.first)
        else
          raise "Impossible case"
      end
      # % on command line is same as * (to avoid file globbing by shell)
      action.filespec = "*" + action.pattern.gsub('%', '*') if action.pattern
      action.delete_field(:pattern)
      # Add action to list of actions to perform
      options.actions << action
    end

    # Check some illegal usages
    
    # --daemon cannot be used with any other option or action
    raise "No other option nor any action allowed in daemon mode" if options.daemon and (options.client or options.web or options.actions.length>0)
    # --web cannot be used with any action
    raise "No action allowed in web server mode" if options.web and options.actions.length>0
    
    # Refuse to use ports<1024 or out of range
    rng = 1024..65535
    raise "Only ports between #{rng.to_s.sub('..',' and ')} are allowed" if not (rng===options.webport) or not (rng===options.port)
    raise "Only ports between #{rng.to_s.sub('..',' and ')} are allowed" if options.rport and not (rng===options.rport)
    
    # Return options
    options
    
    rescue #OptionParser::InvalidOption
      puts opts
      puts
      puts $!
      raise
  end
end



if $0 == __FILE__
  require 'pp'
  options = TradsOptionParser.parse(ARGV)
  PP.pp(options,STDOUT,10)
end
