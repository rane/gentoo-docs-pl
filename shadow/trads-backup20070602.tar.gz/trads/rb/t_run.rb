module T_run
# Quick hack to get stderr from command without using popen3 because
# it forks and drb does not like it
# Using an actual temp file is probably not the fastest way,
# but we are not doing this a lot anyway and we do not expect much on STDERR ;-)

private

  def runrun(rcmd, log=nil)
    log.info("Running #{rcmd}") if log
    # Get a temp file
    tmp = Tempfile.new(".trads.#{rand(rand(9997)).to_s}.", "#{$Base}/tmp")
    # Redirect stderr into temp file
    cmd = "#{rcmd} 2>#{tmp.path}"
    cmd.untaint
    po = IO.popen(cmd)
    stdo = po.readlines.collect{|l|l.chomp!}
    po.close
    # Reopen temp file and read STDERR
    tmp.open
    stdr = tmp.readlines.collect{|l|l.chomp!}
    # Close and unlink temp file
    tmp.close!
    log.info("STDERR : #{stdr.join("\n")}") if log && stdr.length > 0
    # return STDOUT and STDERR
    [stdo, stdr]
  end

end
