module T_web

def wwwTableHeader
  # Count Entries 
  @listEntries = 0
  # Return List Table Header
<<EOT

 <table class="list">
<thead>
 <tr>
  <th>File Name</th>
  <th>#{@langfrom.upcase}</th>
  <th>Timestamp</th>
  <th>#{@langto.upcase}</th>
  <th>Timestamp</th>
  <th>Sync</th>
  <th>CVS Diff</th>
  <th>Who</th>
  <th>Locked</th>
</tr>
</thead>
<tbody>
  
EOT
end

def wwwTableFooter
  # Close List Table
<<EOT

</tbody>
</table>
EOT
end

def wwwFormatEntry(doc)
  @listEntries += 1
  # Format table row for one document
  txt = [""] # Let's have a blank line in our html
  txt << "<tr#{' class=\'even\'' if @listEntries.modulo(2)==0}>"
  txt << "  <td>#{doc.localfilename}</td>"
  txt << "  <td>#{doc.rev}</td>"
  txt << "  <td>#{doc.date}</td>"
  txt << "  <td>#{doc.revLang}</td>"
  txt << "  <td>#{doc.dateLang}</td>"
  txt << if doc.rev > doc.sync and not doc.rev.nil? and not doc.revLang.nil? then
          s = if doc.sync.nil? then "Sync" else doc.sync.to_s end
          "  <td class='syn'><a title='Sync #{doc.localfilename} to #{doc.rev}' href='/action?action=Sync&amp;filename=#{doc.localfilename}'>&nbsp;#{s}</a></td>"
         else
          "  <td class='syn'>&nbsp;#{doc.sync}</td>"
         end
  txt << if doc.rev > doc.sync and doc.sync != "" and doc.rev != "" then
          "  <td class='diff'><a title='View CVS diff between revisions #{doc.sync} and #{doc.rev}' href='/action?action=Diff&amp;filename=#{doc.localfilename}&amp;r1=#{doc.sync}&amp;r2=#{doc.rev}'>View</a></td>"
         else
          "  <td></td>"
         end
  txt << "  <td>#{doc.nick}</td>"
  txt << "  <td>#{doc.lock}</td>"
  txt << "</tr>"
  # Return html-formatted entry with \n just in case you want to read the html
  txt.join("\n")
end

def wwwList(filter, sync, forceCVS=false)
  # Build list that is shown in main screen
  t = wwwTableHeader
  if docs = select(filter) then
    # Get their cvs data
    @documents.getCVSdata(docs, forceCVS)
    # Format output
    docs = docs.sort {|a,b| a[1].localfilename <=> b[1].localfilename}
    docs.each {|d| t << wwwFormatEntry(d[1]) unless sync != "" and d[1].sync>"1.0" and d[1].sync==d[1].rev}
  end
  t << wwwTableFooter
end

def wwwSync(filename)
  if doc = select("^#{filename}$") then # We want an exact match on the filename, hence the ^...$
    # Sync document
    doc[0][1].sync = nil # doc==[[hash key],[TDoc]] hence the [0][1] ; =nil means sync to current revision
    saveXML
  end
end

def wwwDiff(filename, r1, r2)
  # Text defauts to something similar to "nothing to display"
  txt = ["<h2>Nothing much to display.</h2><br/>", "<h3>Maybe you should refresh with [x] Force CVS.</h3>"]
  
  if doc = select("^#{filename}$") then # We want an exact match on the filename, hence the ^...$
    # Get log history and diff (see method's comments to see the structure format)
    doc = doc[0][1] # doc==[[hash key],[TDoc]] hence the [0][1]
    rv, lg, df = doc.getCVSdiff(r1, r2)
    if rv then
      # Output log formatted in html
      txt = Array.new
      txt << "<table class='logdiff'>"
      txt << "<tr class='logTitle'>"
      txt << "  <td colspan='2'>Log history of #{doc.localfilename}</td>"
      txt << "</tr>"

      lg.each {|logentry|
        t = logentry.collect{|l| WEBrick::HTMLUtils.escape(l)}
        txt << "<tr class='logEntry'>"
        txt << "  <td colspan='2'>"
        txt << t[0..2].join("<br />\n") 
        txt << t[3..-1].join(" ") if t.length>3
        txt << "  </td>\n</tr>\n"
      }
      # Output diff formatted for cmd line
      txt << "<tr class='diffTitle'>"
      txt << "  <td colspan='2'>Differences between revisions #{rv[0]} and #{rv[1]}</td>"
      txt << "</tr>"

      df.each {|blk|
        txt << "<tr class='diffLineNumber'>"
        txt << "  <td>Line #{blk[0][0]}</td>"
        txt << "  <td>Line #{blk[0][1]}</td>"
        txt << "</tr>"
        blk[1..-1].each {|txtblk|
          t = txtblk[1].collect{|l| WEBrick::HTMLUtils.escape(l).sub(/^ /,'&nbsp;').gsub(/  /,' &nbsp;')}
          case txtblk[0]
            when "="
              txt << "<tr class='diffSame'>"
              txt << "  <td>#{t.join("<br/>\n")}</td>"
              txt << "  <td>#{t.join("<br/>\n")}</td>"
            when "+"
              txt << "<tr class='diffAdded'>"
              txt << "  <td></td>"
              txt << "  <td>#{t.join("<br/>\n")}</td>"
            when "-"
              txt << "<tr class='diffRemoved'>"
              txt << "  <td>#{t.join("<br/>\n")}</td>"
              txt << "  <td></td>"
            when "~"
              txt << "<tr class='diffChanged'>"
              txt << "  <td>#{t.join("<br/>\n")}</td>"
              t = txtblk[2].collect{|l| WEBrick::HTMLUtils.escape(l).sub(/^ /,'&nbsp;').gsub(/  /,' &nbsp;')}
              txt << "  <td>#{t.join("<br/>\n")}</td>"
          end
          txt << "</tr>"
        }
      }
      # Last row : link to sync document
      txt << "<tr class='syn'>"
      txt << "  <td colspan='2'><a href='/action?action=Sync&amp;filename=#{doc.localfilename}'>Sync #{doc.localfilename}  (#{doc.rev})</a></td>"
      txt << "</tr>"
      # Close Table
      txt << "</table>"
    end
  end
  txt.join("\n") # Add \n to help read the html
end
end #module


class TWeb

def wwwAction(request)
  # Reset output buffer
  action = www = ""
  # Redirect to / by default
  redir = nil
  
#-# DEBUG (Display URL's params)
#www << "It is now #{`date`}<br/>"
#request.query.each {|k,v| www<<"request.query['#{k}']=#{v} <br/>"}
#-# END

  action = request.query['action'].upcase if request.query['action'] #Just a precaution against missing action
  if action =~ /LIST/
    # Get navigation bar params
    @wwwFilter = request.query['filespec'] if request.query['filespec']
    @wwwSync = if request.query['sync'] then "checked='checked'" else "" end
    forceCVS = request.query['cvs'] == 'y'
    www << @tt.wwwList(@wwwFilter, @wwwSync, forceCVS)
  elsif action =~ /SYNC/
    @tt.wwwSync(request.query['filename']) if request.query['filename']
    redir = "/action?action=LIST#{"&sync=Sync" if @wwwSync}"
  elsif action =~ /DIFF/
    www << if request.query['filename'] and request.query['r1'] and request.query['r2']
             @tt.wwwDiff(request.query['filename'], request.query['r1'], request.query['r2'])
           else
             redir = "/action?action=LIST#{"&sync=Sync" if @wwwSync}"
           end
  elsif action =~ /UPLOAD/
    # Format list of upload files for html
    lst = @tt.doUpload
    www << "<div class='list'><h2>Uploaded</h2><ul><li>#{lst.collect{|l|File.basename(l)}.join("</li>\n<li>")}</li></ul></div>"
  elsif action =~ /STOP/
    redir = "/byebye"
  end
  [www, redir]
  
  rescue 
    # Something went bad
    @tt.tlog("Web Ooopsie:#{$!}")
    www << "<h1>Ooops!</h1><br/><h3><font color='#F00000'>#{$!}</font></h3>"
end


def startWeb
  # Define Instance Variables referenced by html file
  @wwwSync = 'checked="checked"'
  @wwwFilter = "*"
  @html = File.open("#{File.dirname($0)}/html/t_menu.html"){|f| html = f.readlines.join}
  
  # Use logfile, or use STDERR
  log = @tt.log||STDERR
  logger    = WEBrick::Log::new(log, WEBrick::Log::INFO)
  customlog = WEBrick::Log::new(log)

  s = WEBrick::HTTPServer.new(
    :BindAddress    => "127.0.0.1",
    :Port           => @port,
    :Logger         => logger,
    :AccessLog      => [
      [ customlog, "%r - %s - %Ts" ]
    ]
  )

  s.mount_proc("/") {|req, res|
    # Display main page
    res['Content-Type'] = "text/html"
    res.set_redirect(WEBrick::HTTPStatus::TemporaryRedirect, "/action?action=LIST")
  }
    
  s.mount_proc("/action") {|req, res|
    # Handle action
    @tt.mutex.synchronize{
      www, redir = wwwAction(req)
      # Redirect
      if redir then
        res.set_redirect(WEBrick::HTTPStatus::TemporaryRedirect, redir)
      else
        body = @html.sub("${wwwSync}", "#{@wwwSync}").sub("${wwwFilter}", "#{@wwwFilter}")
        # When text contains a \' (as in alsa-guide.xml)
        # it is interpreted as post-match and disrupts output
        md=%r[\$\{wwwContent\}].match(body)
        res.body << md.pre_match + www + md.post_match if md
      end
    }
  }

  # Mount regular directories
  s.mount("/css", WEBrick::HTTPServlet::FileHandler, "#{$Base}/css")
  s.mount("/images", WEBrick::HTTPServlet::FileHandler, "#{$Base}/images")

  # mount /byebye. self-explanatory ;-)
  s.mount_proc("/byebye") { |req, res|
    res.body = "<HTML><H1>Adieu monde cruel !</H1></HTML>"
    res['Content-Type'] = "text/html"
    # Wake up stop thread that will shutdown web server
    $stopme.wakeup
  }

  # Create thread to sleep for a second before shutting down web server to let it
  # send its answer on <quit> request
  $stopme = Thread.new { Thread.stop; sleep(1); s.shutdown }

  # Exit nicely on Ctrl-C / kill
  trap("INT"){ s.shutdown }

  puts "Starting web interface on port #{@port}"
  s.start
end

def initialize(port, ttrads)
  @port = port
  @tt = ttrads
end

end

