#! /usr/bin/ruby

# Written by Xavier Neys 29-sep-2003
# Updated 05-Dec-2003
# Updated 08-Feb-2004 : new links into viewCVS
# Updated 10-Feb-2004 : old links into viewCVS are back, thanks guys :-(
# Updated 27-Feb-2004 : script now relies on environment for xml catalog.
#                       You should add the following line
#                         <rewriteURI uriStartString="/dtd/" rewritePrefix="/path/to/dtd/" />
#                       to /etc/xml/catalog and define the path to the DTDs
#                       Script now also handles doc/{LANG}/insert-{LANG}.xml by passing --path to xsltproc
# Updated 11-Mar-2004 : Link to handbook index is wrong (should not pass ?part=-1)
# Updated 31-Mar-2004 : Handle ARCH specific handbooks

# Updated Apr-2004    : Major update. Added CLI feature, remote access with drb and simple web interface

# Updated Aug-2004    : Fixed bug in link generation
# Updated Aug-2004    : New version w/ grouping and several handbooks
# Updated Jan-2005    : Handbooks can have a prior attribute
#                       Use gorg to process files instead of xsltproc
# Updated 02-Jun-2005 : Handbooks need to be processed from their directory because they access all their parts
#                       We don't need chapter and part numbers because handbooks files can now be rendered directly
# Updated 26-Jul-2005 : Use  wwwdev only as destination for scp to make it easier for translators with r/o access
# #
# Updated 26-Nov-2005 : Add dohtml attribute, "no" == do not generate html files, upload xml only

# Documentation available on http://dev.gentoo.org/~neysx/trads-doc.html

# Generate  & Manage Gentoo translations coordination page

require 'rexml/document'
require 'webrick'
require 'drb'
require 'tempfile'
require 'thread'
require 'yaml'
require 'logger'

# Define basedir, probably current, but not necessarily
$Base = File.expand_path(File.dirname($0)).sub(/\/rb$/, "")

# Our .rb files are under rb/
$: << "#{$Base}/rb"
require 't_rev.rb'
require 't_opts.rb'
require 't_web.rb'
require 't_rev.rb'
require 't_run.rb'

def ldate
  Time.now.utc.to_s
end

## Boiler plate of .xml to put around our generated table
require 'trads.template.rb'


class TTrads
  include T_web
  include T_run
  
  class TTraducteurs < Hash
    def initialize(xmlNode)
      # Build hash of translators nick => email
      REXML::XPath.each(xmlNode, "translator") { |t| self.store( t.attributes['nick'], t.attributes['email']) }
    end
  end


  class TDocumentBase
    attr_reader :ttrad, :id, :filename, :localfilename, :uniquefilename, :path, :subdir, \
                :target, :rev, :date, :revLang, :dateLang, :sync, :html, :lastCVSaccess, :nick, :lock

    include T_run
    
    def initialize(doc, ttr)
      # Init document info
      @ttrad    = ttr
      @doc      = doc
      @id       = doc.attributes["ID"]
      @nick     = doc.elements["info"].attributes["nick"]
      @lock     = doc.elements["info"].attributes["lock"]
      @sync     = RevNum.new(doc.elements["rev"].attributes["sync"])
      @target = RevNum.new(doc.elements["rev"].attributes["target"])
      @html = @date = @dateLang = ""
      @rev = @revLang = RevNum.new
      @r1 = @r2 = RevNum.new
      @r1, @r2 = @sync, @target if (@sync!=@target) and (@sync!="") and (@target!="")
      @lastCVSaccess = 0
    end

    def wwwFile
      "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}?style=printable"
    end

    def wwwFileLang
      "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langto}/#{@subdir}#{@filename}?style=printable"
    end

    def hbdoc?
      nil
    end

    def up2date?
      (@sync == @rev) and (@revLang != "")
    end

    # Default is no group, i.e. ""
    def group
      @group || ""
    end
    def group=(grp)
      @group = ""
    end
    
    def diffAgainst
      if @target == "" and @rev > @sync
        @rev
      elsif @target != ""
        @target
      end
    end
    
    def diffURL
      # Return label and url to diff on cvsweb between r1 and r2 of en version
      if @sync != "" and diffAgainst then
        return "#{@sync} - #{diffAgainst}", "http://sources.gentoo.org/viewcvs.py/#{@ttrad.cvsroot}/#{@ttrad.cvspath}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}?r2=#{diffAgainst}&amp;r1=#{@sync}&amp;diff_format=l"
      else
        return nil
      end
    end
    
    def getCVSdiff(r1, r2)
      # Run cvs log -rSYNC -rREV files.xml to get log history between sync version and current version
      #  AND
      # Run cvs diff -y to get nice diff between revisions
      # Return "" if no revisions are known or docs are already in sync
      # Otherwise return a structure that can easily be used by both the cmd line and the web
      #
      # An array with the following items is returned:
      #
      #  -Revision numbers: array of two revision numbers
      #  -History log: array of log entries
      #    each log entry is an array of strings whose first item is 'revision x.y'
      #  -Diff array: array of diff blocks
      #    diff block is an array of several arrays as follows
      #      first array: line numbers [l1, l2] (from the @@ line if you know diff)
      #      followed by: arrays of text blocks
      #      A text block is itself an array.
      #      The first element is a one-char string: "=", "~", "-" or "+"
      #      indicating respectively common text, changed text, removed text or added text
      #      The second element is an array of strings containing the lines of text
      #      A third element is present when text has been changed (indicator "~")
      #      In this case, the second element is an array of removed lines and the third is an array of added lines
      #
      # Sample:
      #[
      # ["1.4", "1.8"]
      #,
      # [["revision 1.4",
      # "date: 2004/04/08 13:02:10;  author: swift;  state: Exp;  lines: +43 -7",
      # "Blah blah",
      # "More blah blah."],
      # ["revision 1.3",
      # "date: 2004/04/04 06:34:12;  author: neysx;  state: Exp;  lines: +3 -4",
      # "And even more cruft."],
      # ["revision 1.2",
      # "date: 2004/04/02 16:30:45;  author: neysx;  state: Exp;  lines: +3 -3",
      # "s/three/two/ grub and lilo configs"]]
      #,
      # [[["18", "18"],
      # ["=", ["<license/>", ""]],
      # ["~",
      #  ["<version>1.0</version>", "<date>April 2, 2004</date>"],
      #  ["<version>1.1</version>", "<date>April 5, 2004</date>"]],
      # ["=", ["", "<chapter>"]]],
      # [["59", "59"],
      # ["=",
      # ["  <li><uri link=\"handbook-amd64.xml\">Gentoo Linux/AMD64 Handbook</uri></li>",
      #  "  <li><uri link=\"handbook-ppc.xml\">Gentoo Linux/PPC Handbook</uri></li>"]],
      # ["~",
      #  ["  <li><uri link=\"draft/handbook-sparc.xml\">(Gentoo Linux/SPARC Handbook)</uri></li>"],
      #  ["  <li><uri link=\"handbook-sparc.xml\">Gentoo Linux/SPARC Handbook</uri></li>"]],
      # ["=",
      #  ["  <li><uri link=\"handbook-alpha.xml\">Gentoo Linux/Alpha Handbook</uri></li>",
      #   "  <li><uri link=\"handbook-mips.xml\">Gentoo Linux/MIPS Handbook</uri></li>"]]],
      # [["65", "65"],
      # ["=", ["</ul>", ""]],
      # ["-",
      #  ["<p>",
      #   "The <uri link=\"draft/handbook-sparc.xml\">Gentoo Linux/SPARC Handbook</uri> is",
      #   "not completely finished yet. We are awaiting input from the SPARC developers",
      #   "regarding the partitioning of a SPARC system. If you know how to partition your",
      #   "SPARC system then you can safely use this draft Handbook.",
      #   "</p>",
      #   ""]],
      # ["=", ["</body>", "</section>"]]]]
      #]
      #
      return nil if @rev<="0.0" or @sync<="0.0" or @rev==@sync
      
      # See if diff is in our cache
      yfile = "#{$Base}/cache/.#{@uniquefilename}.diff.yaml"; yfile.untaint
      diff = YAML::load(File.open(yfile)) if FileTest.file?(yfile)
      
      return diff if diff and r1==diff[0][0] and r2==diff[0][1] # We have already done the diff
      
      # Get history log
      cmd = "cd #{@ttrad.localcvs}; cvs -z3 log -r#{@sync.succ}:#{@rev} #{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}"
      # Run cvs command
# DEBUG begin
#  read from local file cvs.log instead (no need to load actual cvs)
#puts "NOT RUNNING  #{cmd}"
#pe=[]
#po=File.new("/tmp/cvs.hist").readlines.collect{|l|l.chomp!}
      po, pe = runrun(cmd, @ttrad.log)
# DEBUG end
      raise "CVS was not happy!\n\n#{pe.join("\n")}" if pe.length>0
      # Parse CVS output into an array of arrays, one per commit
      log = []
      while ln = po.find{|l| l =~ /^revision \d+\.\d+$/} do
        # Cut out cruft before log entry
        po.slice!(0, po.index(ln))
        # Find end of entry (all - or all =)
        en = po.find{|l| l =~ /^((-+)|(=+))$/}
        # Slice entry out of CVS output into our result array
        log << po.slice!(0, po.index(en))
      end
      
      # Diff the revisions
      cmd = "cd #{@ttrad.localcvs}; cvs -z3 diff -kk -t -U6 -r#{@sync} -r#{@rev} #{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}"
      # Run cvs command
# DEBUG begin
#  read from local file cvs.log instead (no need to load actual cvs)
#puts "NOT RUNNING  #{cmd}"
#pe=[]
#po=File.new("/tmp/cvs.diff").readlines.collect{|l|l.chomp!}
      po, pe = runrun(cmd, @ttrad.log)
# DEBUG end
      raise "CVS was not happy!\n\n#{pe.join("\n")}" if pe.length>0
      # Parse CVS output into an array of arrays, one per commit
      diff = []
      ln = po.find{|l| l =~ /^@@ -(\d+),\d+ \+(\d+),\d+ @@$/}
      if ln then
        # Cut out cruft before diff block, including @@ line numbers @@
        po.slice!(0, po.index(ln)+1)
        # Start a new diff block
        blk = [[$1,$2]]
        oldL = []; newL = []; sameL = []
        po.each {|ln| 
          case ln
            when /^-/
              # Add block of common text to blk
              blk << ['=', sameL] if sameL.length > 0
              sameL = []
              # Add line to block of removed lines
              oldL << if ln.length>1 then ln[1..-1] else " " end
            when /^\+/
              # Add block of common text to blk
              blk << ['=', sameL] if sameL.length > 0
              sameL = []
              # Add line to block of new lines
              newL << if ln.length>1 then ln[1..-1] else " " end
            when /^ /
              if oldL.length + newL.length > 0 then
                # We have had some changes, can be del/add/change
                blk << ['~', oldL, newL] if oldL.length>0 and newL.length>0
                blk << ['-', oldL]       if oldL.length>0 and newL.length<1
                blk << ['+', newL]       if oldL.length<1 and newL.length>0
                oldL = []; newL = []
              end
              sameL << if ln.length>1 then ln[1..-1] else " " end
            when /^@@ -(\d+),\d+ \+(\d+),\d+ @@$/
              # New block with new line numbers
              # Add last block of common text from previous block (right before @@...@@)
              blk << ['=', sameL] if sameL.length > 0
              # Add block to our diff array
              diff << blk
              # Start a new block
              blk = [[$1,$2]]
              oldL = []; newL = []; sameL = []
           end
        }
        # End of cvs diff output processing
        # Add current blocks of text
        blk << ['=', sameL] if sameL.length > 0
        # Add block to our diff array
        diff << blk
      end
      # Keep diff for future requests
      diff = [[r1.to_s, r2.to_s], log, diff]
      File.open(yfile, File::CREAT|File::WRONLY|File::TRUNC){|f|f.puts diff.to_yaml}
      # Return it
      diff
    end
    
    def getXML(r=nil)
      # Get .xml source file of given revision of document
      # if r==nil, then get latest revision
      #
      @ttrad.log.info("I need #{@localfilename}")
      # Make sure we have the CVS data for this document
      @ttrad.documents.getCVSdata([[0, self]])
      rev = r||@rev
      # First, check if file is in our cache
      yfile = "#{$Base}/cache/.#{@uniquefilename}.yaml"; yfile.untaint
      yxml = YAML::load(File.open(yfile)) if FileTest.file?(yfile)
      return yxml[1] if yxml and rev == yxml[0]
      
      # Check the CVS status to see if our local copy of the CVS matches the requested revision
      cmd = "cd #{@ttrad.localcvs}; cvs -z3 status #{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}"
      # Run cvs command
      po, pe = runrun(cmd, @ttrad.log)
      raise "CVS was not happy!\n\n#{pe.join("\n")}" if pe.length>0
      # Look for 'Working revision:   M.m'
      wr = po.find{|l| l=~ /^\s*Working revision:\s*(\d+\.\d+)$/}
      if wr and rev == $1 then
        # Read file from local CVS (faster than from repository)
        @ttrad.log.info("Getting #{@localfilename} from local CVS")
        yxml = [$1]
        f = "#{@ttrad.localcvs}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}"; f.untaint
        File.open(f){|f| yxml << f.readlines.collect{|l|l.chomp!}}
        raise "Failed to read #{f} from local CVS" if yxml[1].length < 1
      else
        # We need to get the file from the CVS repository
        # We do not want to alter anything in the user's local repository
        # Therefore we use cvs -p -r{revision} and read the file from stdout
        @ttrad.log.info("Getting #{@localfilename} (#{rev}) from repository")
        # Run cvs command
        cmd = "cd #{@ttrad.localcvs}; cvs -q -z3 update -p -r#{rev} #{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}"
        po, pe = runrun(cmd, @ttrad.log)
        raise "CVS was not happy!\n\n#{pe.join("\n")}" if pe.length > 0
        raise "Cannot download #{@localfilename} from CVS.\nMaybe you should try to update your CVS copy." if po.length < 1
        yxml = [rev.to_s]
        yxml << po
      end
      # Cache the file (format is similar to diff, i.e. [rev,[file]])
      File.open(yfile, File::CREAT|File::WRONLY|File::TRUNC) {|f| f.puts yxml.to_yaml}
      # Return the file content
      yxml[1]
    end

    def generateTarget
      # Generate .html file for target if there is one, return .html file name or ""
      if @target == "" then
        return nil
      else
        # Get .xml file
        xml = getXML(@target)
        # Save .xml file
        localf = "#{$Base}/work/#{@uniquefilename}"; localf.untaint
        File.open(localf, File::CREAT|File::WRONLY|File::TRUNC) {|f| f.puts xml}
        # Render .html file
        xparam = gorgParams
        if  @ttrad.dohtml then
          @html = @ttrad.xml2html(localf, xparam, localf, "#{@ttrad.localcvs}/#{@path}/#{@ttrad.langfrom}/#{@subdir}")
        else
          @html = localf
        end
      end
     end

    def set_cvsdata(lang, rev, dat)
      # Store revision number and modification date for given language
      @rev,@date = RevNum.new(rev),dat if lang == @ttrad.langfrom
      @revLang,@dateLang = RevNum.new(rev),dat if lang == @ttrad.langto
      @lastCVSaccess = Time.new().to_i
    end
    
    def sync=(newsync)
      # Set new sync value, 0=reset to nil, nil/empty=latest
      newsync = RevNum.new(newsync) if newsync.class != RevNum
      case newsync.to_s 
        when ""    then @sync = @rev
        when "0.0" then @sync = RevNum.new
        else            @sync = newsync
      end
      # Update our xml document
      @doc.elements["rev"].attributes["sync"] = @sync.to_s
      # Clear @target unless it is still higher than @sync
      @target = RevNum.new unless @target > @sync
      @doc.elements["rev"].attributes["target"] = @target.to_s
    end
    
    def nick=(nick)
      # [Re]Set new nick
      @nick = nick
      # Update our xml document
      @doc.elements["info"].attributes["nick"] = @nick
    end
    
    def lock=(nick)
      # [Re]Set new lock value to nick
      @lock = nick
      # Update our xml document
      @doc.elements["info"].attributes["lock"] = @lock
    end

    def gorgParams
      # Define params to be passed to gorg
      # add --param style printable
      return "--param style printable "
    end
    
    def target=(t)
      # Set new target value, 0=reset to nil, nil/empty=latest
      t = RevNum.new(t) if t.class != RevNum
      case t.to_s 
        when ""    
          raise "Translation of #{@localfilename} is already up-to-date" if @rev == @sync
          @target = @rev
        when "0.0"
          @target = RevNum.new
        else
          # Target must be > @sync and <= @rev
          raise "Translation of #{@localfilename} is already up-to-date" if @rev == @sync
          raise "Translation of #{@localfilename} must target a revision later than #{@sync}"  if t <= @sync
          raise "Translation of #{@localfilename} cannot be based on an unknown revision" if t >  @rev
          @target = t
      end
      # Update our xml document
      @doc.elements["rev"].attributes["target"] = @target.to_s
    end
    
    ListFormat = "%1.1s %-5.5s %-5.5s %-10.10s %-5.5s %-10.10s  %s %s"
    def list
      # Return formatted string for current doc when asking for a list of files
      c1 = "?" if @revLang=="" or @sync==""
      c1 = "<" if @sync!=@rev and @sync!=""
      sprintf(ListFormat, c1, @rev, @sync, @nick, @target, @group, @localfilename, ("[#{@lock}]" if (@lock||"")!="") )
    end
    
    def listH
      # Return title string matching output of list
      sprintf(ListFormat, "S", "Rev.", "Sync.", "Who", "Targ.", "Group", "File", "")
    end
    
    def to_s
      # Output table row
      r = Array.new

      # Start with doc name
      r << @id
      
      # Dots
      dots = ""
      ndots,colour = if up2date? then
                       # Doc up2date, a single green dot
                       dots += "<img src=\"images/empty.png\" />"
                       [1, "green"]
                     else
                       # If doc is being translated, start with a blue dot,
                       # otherwise use an empty one for alignment purposes
                       dots += if @target != "" then "<img src=\"images/blue.png\" />"
                                                else "<img src=\"images/empty.png\" />"
                               end
                       # How many dots do you see ?
                       ndots = if @sync == "" or @rev == "" then
                                 # Untranslated doc or very old indeed or no English rev (weird)
                                 3
                               else
                                 # How big the gap between current EN version and sync'ed
                                 # version defines the number of dots
                                 case @rev - @sync
                                   when (1..2)  then 1
                                   when (3..5)  then 2
                                   when (6..10) then 3
                                   else              4
                                 end
                               end
                       # What is your favourite colour ?
                       case @prior
                         when "C" then [ndots, "red"]
                         when "I" then [ndots, "orange"]
                         when "N" then [ndots, "yellow"]
                         else          [ndots, "white"]
                       end
                     end

      dots += "<img src=\"images/#{colour}.png\" />" * ndots
      r << dots
      
      # Add doc info
      r << "<uri link=\"#{wwwFile}\">#{@rev}</uri>" \
           " (<uri link=\"http://sources.gentoo.org/viewcvs.py/#{@ttrad.cvsroot}/#{@ttrad.cvspath}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}?rev=#{@rev}&amp;content-type=text/plain\">xml</uri>)"
      r << @date
      r << if @revLang != "" then 
             "<uri link=\"#{wwwFileLang}\">#{@revLang}</uri>" \
             " (<uri link=\"http://sources.gentoo.org/viewcvs.py/#{@ttrad.cvsroot}/#{@ttrad.cvspath}/#{@path}/#{@ttrad.langto}/#{@subdir}#{@filename}?rev=#{@revLang}&amp;content-type=text/plain\">xml</uri>)"
           else 
             "" 
           end
      r << @dateLang
      r << "#{@sync}"
      r << if rdf = diffURL then "<uri link=\"#{rdf[1]}\">#{rdf[0]}</uri>" else "" end
      r << if @target != "" then
              # Link if we successfully generated a .html file 
              # Give a link to xml source of this revision
              xml = " (<uri link=\"http://sources.gentoo.org/viewcvs.py/#{@ttrad.cvsroot}/#{@ttrad.cvspath}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}?rev=#{@target}&amp;content-type=text/plain\">xml</uri>)"
              if @html != "" then
                 "<uri link=\"#{File.basename(@html)}\">#{@target}</uri>#{xml}" 
              else
               "#{@target}#{xml}" # Simply display revision number with link to xml source
              end
           else 
              "" 
           end
      email = @ttrad.traducteurs[@nick]
      r << if email != "" && @rev != @sync then 
              if @target != "" then
                "<b><mail link=\"#{email}\">#{@nick}</mail></b>"
              else
              "<brite>#{@nick}</brite>"
              end
           else
              "#{@nick}"
           end
    
      # Done, return line
      "<tr><ti>" + r.join('</ti><ti>') + "</ti></tr>\n"
    end

  end


  class TDocument < TDocumentBase
    
    def initialize(doc, ttr)
      super
      @filename       = doc.elements["files"].attributes["name"]
      @uniquefilename = @filename.capitalize
      @path           = doc.elements["files"].attributes["path"]
      @prior          = doc.elements["info"].attributes["prior"]
      @group          = doc.elements["info"].attributes["group"]
      # When doc is deeper than doc/{LANG}, e.g. proj/en/gdp/doc
      @subdir         = doc.elements["files"].attributes["subdir"]||""
      # Make sure subdir ends with / if subdir exists
      @subdir         = @subdir.sub(/\/*$/,"")+"/" if @subdir.length > 0
      @localfilename = "#{@path}/#{subdir}#{@filename}"
      @uniquefilename = "#{@localfilename}".gsub('/','_')
    end

    # wwwFile/wwwLang are now same as handbooks', they have been moved to TDocumentBase
#    def wwwFile
#      "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}?style=printable"
#    end

#    def wwwFileLang
#      "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langto}/#{@subdir}#{@filename}?style=printable"
#    end

    def hbdoc?
      false
    end

    def group=(grp)
      # [Re]Set group attribute
      @group = grp
      # Update our xml document
      @doc.elements["info"].attributes["group"] = @group
    end
  end


  class TDocumentHB < TDocumentBase
    attr_reader :index, :hbNum, :hbPos, :label #,:chap, :part
    
    def initialize(doc, ttr, label='', num=1, pos=1)
      super(doc, ttr)
      @subdir   = doc.parent.attributes["subdir"].sub(/\/*$/,"")+"/"
      @filename = doc.attributes["filename"]
      @path     = doc.parent.attributes["path"]
      @prior    = doc.parent.attributes["prior"]
      @localfilename = "#{@path}/#{subdir}#{@filename}"
      @uniquefilename = "#{@localfilename}".gsub('/','_')
      # Use num to distinguish different handbooks and pos 
      # to remember position in xml file to keep same sequence on generated list
      @hbNum = num
      @hbPos = pos
      @label = label
      # These 3 fields are used to render individual html pages (not used anymore)
#      @chap     = doc.attributes["chap"]||0
#      @part     = doc.attributes["part"]||0
      # index is now ARCH specific
#      @index    = doc.parent.attributes["index"].strip
#      if @index =~ /-ARCH/ then
        # If -ARCH was not found in index, keep it as it is (old handbook.xml or another book)
#        archlist = doc.parent.attributes["archlist"].split
#        raise "Architecture list is empty" unless archlist.length >= 1
        # If filename contains one of the arch, replace ARCH in index with it
        # i.e. handbook-ARCH.xml becomes handbook-x86.xml if -x86 appears in filename
#        if @part.to_i == 0 then
          # filename IS the index, no need to parse anything
#          @index = @filename
#        else
#          r = Regexp.new("(-#{archlist.join(')|(-')})") # e.g. /(-x86)|(-ppc)|(-mips)|(-amd64)|(-hppa)|(-alpha)|(-sparc)/
#          md = r.match(@filename)
          # If NoMatch, replace -ARCH in index with first available architecture
#          md = "-#{archlist[0]}" unless md
          # Replace -ARCH in index
#          @index.gsub!(/-ARCH/, md.to_s)
#        end
#      end
    end

    # wwwFile/wwwLang are now same as guides', they have been moved to TDocumentBase
#    def wwwFile
#      case @part.to_i <=> 0
#        when 1 then
#          # Regular chapter
#          "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@index}?part=#{@part}&amp;chap=#{@chap}&amp;style=printable"
#        when 0 then
#          # Handbook main page, use filename instead of index to get handbook-x86.xml e.g.
#          "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}?part=#{@part}&amp;chap=#{@chap}&amp;style=printable"
#        when -1 then
#          # Not a handbook chapter, just a normal page inside handbook structure, e.g. index.xml
#          "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langfrom}/#{@subdir}#{@filename}?style=printable"
#      end
#    end

#    def wwwFileLang
#     case @part.to_i <=> 0
#        when 1 then
#          # Regular chapter
#          "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langto}/#{@subdir}#{@index}?part=#{@part}&amp;chap=#{@chap}&amp;style=printable"
#        when 0 then
#          # Handbook main page, use filename instead of index to get handbook-x86.xml e.g.
#          "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langto}/#{@subdir}#{@filename}?part=#{@part}&amp;chap=#{@chap}&amp;style=printable"
#        when -1 then
#          # Not a handbook chapter, just a normal page inside handbook structure, e.g. index.xml
#          "#{@ttrad.wwwroot}/#{@path}/#{@ttrad.langto}/#{@subdir}#{@filename}?style=printable"
#      end
#    end

    def hbdoc?
      true
    end

  end

  
  class TDocuments < Hash
    attr_reader :ttrad
    include T_run

    def initialize(xmlRootNode, ttr)
      @ttrad = ttr
      # Build hash of documents
      REXML::XPath.each(xmlRootNode, "documents/doc") { |d|
        dd = TDocument.new(d, @ttrad)
        self.store( "#{dd.localfilename}", dd)
      }
      # Handbook(s), just number them from 1
      n = 1
      REXML::XPath.each(xmlRootNode, "handbook") { |hb|
        nn = 1
        label = hb.attributes['label']
        REXML::XPath.each(hb, "hbdoc") { |d|
          dd = TDocumentHB.new(d, @ttrad, label, n, nn)
          self.store( "#{dd.localfilename}", dd)
          nn += 1
        }
        # Next handbook
        n += 1
      }
    end

#    def hbIndex(d)
#      # Return doc which is the handbook index (e.g. handbook-x86.xml) for given document
#      return nil if not d.hbdoc? # Not part of a handbook
#      return d if d.index == d.filename # d _is_ the index
#      a = self.find {|k,v| v.filename == d.index}
#      a[1] if a # Return document
#    end
    
    def getCVSdata(doclist=nil, force=false)
      # Run cvs log -rHEAD list_of_files.xml
      #
      now = Time.new().to_i
      # Build list of file names
      lstf = Array.new
      doclist = self unless doclist # Refresh all docs unless a list is passed
      doclist.each { |n, dd|
        # Refresh data if forceCVS is asked or more than 24 hours have passed
        if force or (now - dd.lastCVSaccess) > 24*60*60 then 
          lstf << "#{dd.path}/#{dd.ttrad.langfrom}/#{dd.subdir}#{dd.filename}"
          lstf << "#{dd.path}/#{dd.ttrad.langto}/#{dd.subdir}#{dd.filename}"
        end
      }
      return if lstf.length < 1  # Nothing to do
      # build cvs command
      cmd = "cd #{@ttrad.localcvs}; cvs -z9 log -rHEAD #{lstf.join(" ")}"
      # Run cvs command
# DEBUG begin
#  read from local file cvs.log instead (no need to load actual cvs)
#puts "RUNNING  #{cmd}"
#puts "NOT RUNNING  #{cmd}"
#pe=[]
#po=File.new("/tmp/cvs.log").readlines.collect{|l|l.chomp!}
      po, pe = runrun(cmd, @ttrad.log)
#puts "GOT  #{po.join("\n")}"
#puts "ERR  #{pe.join("\n")}"
# DEBUG end
      # Parse CVS output
      #  1) Select lines with file name or revision number or date
      cvs = po.select {|line| /(^Working file: )|(^revision \d+\.\d+$)|(^date: \d{4})/ =~ line}
      #     This gives something like
      #       Working file: doc/fr/gentoo-x86-quickinstall.xml
      #       revision 1.6
      #       date: 2004/03/13 14:26:05;  author: neysx;  state: Exp;  lines: +3 -5
      #       Working file: doc/en/gentoo-x86-quickinstall.xml
      #       revision 1.10
      #       ...
      
      #       Bork if number of lines is not multiple of 3 (3 lines per file)
      raise "Something is missing in CVS log output\n#{cvs.join('\n')}" if cvs.length.modulo(3) != 0
      #  2) Extract [file name],[revision],[date] from filtered cvs output
      cvs.collect! do |line|
        case line.chomp
          when /^Working file: /
            $'
          when /^revision /
            $'
          when %r!^date: (\d{4}.\d\d.\d\d \d\d:\d\d):\d\d!
            $1
        end
      end
      #  3) Process items, at last ;-)
      (cvs.length/3).times {
        # split [file, revision, date]
        f, r, d = cvs.slice!(0..2)
        # Match file path against languages, i.e. /en/ or /fr/ or /da/ ...
        # and save info, don't bother if no language is found
        if f =~ %r[/(#{@ttrad.langto}|#{@ttrad.langfrom})/(.*)] then
          l = $1
          hkey = f.strip.sub("/#{l}",'')
          self[hkey].set_cvsdata(l, r, d) if self.key?(hkey)
        end
      }
      # return any insanity cvs might have returned, but filter out the "nothing known about"
      pe.reject { |l| l =~ /nothing known about/ }
    end
    
    def generateTargets
      # Generate html for each doc with a defined target and return list of .html files
      lst = Array.new
      # Gather list of docs
      self.each { |n,d| 
        l = d.generateTarget
        lst << l if l
      }
      @ttrad.log.info("Generated #{lst.join(", ")}")
      lst
    end
    
    def to_s(outdatedOnly=false)
      # Output table of documents
      #
      s = ""
      # Blah blah before table and update <date> element
      #
      s += $Part1.sub(/(?m)<date>.*<\/date>/, "<date>#{ldate}</date>")
      # Column headers
      s += @ttrad.to_H

      # Collect standard documents and sort them
      # Collecting and sorting next allows for different sorting schemes
      # between individual docs (could be on nick,id) and handbook pages (part/chap/id)
      # Note: When Hash becomes an Array, it looks like [[key,value], [key,value], ...]

      # Collect standard documents
      arDocs = self.to_a.select { |kv| not kv[1].hbdoc? }
      # Sort on Group/ID (=label displayed in 1st column)
      arDocs.sort! { |a,b| [a[1].group.upcase, a[1].id.upcase] <=> [b[1].group.upcase, b[1].id.upcase] }
      # Output and break on group
      grp = arDocs[0][1].group
      arDocs.each do |d|
        if not (outdatedOnly  and d[1].up2date?) then
          # Break on group change
          if d[1].group != grp then
            grp = d[1].group
            s += @ttrad.to_H(grp)
          end
          s += d[1].to_s
        end
      end

      # Collect handbook documents and sort them, if any
      arDocs = self.to_a.select { |kv| kv[1].hbdoc? }
      if arDocs.length >= 1 then
        num = nil
        # Sort on book number, ID
        arDocs.sort! { |a,b| [a[1].hbNum, a[1].hbPos] <=> [b[1].hbNum, b[1].hbPos] }
        # Output handbook files
        arDocs.each do |d|
          if not (outdatedOnly  and d[1].up2date?) then
            # Repeat column headers before each handbook
            if num != d[1].hbNum then
              num = d[1].hbNum
              s += @ttrad.to_H(d[1].label)
            end
            s += d[1].to_s 
          end
        end
      end

      # Blah blah after table
      s += $Part2
    end
  end
  
    #
   # #
  #^,^#  Main Class: TTrads
   # #
    #

  attr_reader :langfrom, :langto, :cvsroot, :cvspath, :localcvs, :wwwroot, :wwwdev, :dohtml, :traducteurs, :documents, :log, :mutex

  def initialize(xmlfilename)
    @xmlfilename = xmlfilename
    @xmlfilename.untaint
    # Validate document with xmllint
    cmd = "xmllint --valid --noout #{@xmlfilename}"
    # Run command through pipe
    po, pe = runrun(cmd)
    raise "  >>> Invalid #{@xmlfilename} <<<\n#{pe}" if pe.length > 0

    # Create log file
    l = "#{$Base}/log/trads.log"; l.untaint
    @log = Logger.new(l, 8, 100000) # keep at most 8 files of 100000 bytes
    @log << "=-"*40+"=\n"
    tlog("#{$0} started")
    
    # Get a mutex to block concurrent access when executing an action
    @mutex = Mutex.new
    
    # Open xml document
    @xmlDoc = REXML::Document.new(File.new(@xmlfilename))
    
    # Set some class globals
    @cvsroot   = @xmlDoc.root.elements["config"].attributes["cvsroot"]
    @cvspath   = @xmlDoc.root.elements["config"].attributes["cvspath"]
    @wwwroot   = @xmlDoc.root.elements["config"].attributes["wwwroot"]
    @wwwdev    = @xmlDoc.root.elements["config"].attributes["wwwdev"]
    @localcvs  = @xmlDoc.root.elements["config"].attributes["localcvs"]
    @langfrom  = @xmlDoc.root.elements["config"].attributes["langfrom"]
    @langto    = @xmlDoc.root.elements["config"].attributes["langto"]
    @genfile   = @xmlDoc.root.elements["config"].attributes["genfile"]
    @dohtml    = @xmlDoc.root.elements["config"].attributes["dohtml"] == "yes"

    @genhtml = []
    @genxml = ""
    @targetList = []
    
    # Build list of translators. traducteurs['nick'] gives email
    @traducteurs = TTraducteurs.new(@xmlDoc.root.elements["translators"])
    # Build list of documents
    @documents = TDocuments.new(@xmlDoc.root, self)
    tlog("#{@xmlfilename} loaded")
  end
  
  def tlog(str)
    # Let's keep it simple for the moment, just dump the string into the log
    @log.info(str)
  end
  
  def saveXML
    File.open(@xmlfilename, File::CREAT|File::TRUNC|File::WRONLY) {|f| @xmlDoc.write(f,-1)}
    tlog("#{@xmlfilename} saved")
  end

  def xml2html(fname, gorgParams="", xname=fname, dir=".")
    # run gorg on given file and write result in .html
    # return html file name if success

    fname.untaint; dir.untaint
    Dir.chdir(dir) {
      cmd = "gorg < #{fname} #{gorgParams}"
      # Run command through pipe
      po, pe = runrun(cmd, @log)
      raise "  --= Call to gorg failed =--<br/>#{pe.join("<br/>")}"  if pe.length > 0
      # Assume that if output ended with </html>, it went OK
      if po[-1] =~ /<\/html>/ then
        # Remove leading / on path to images and css and save .html file.
        html = xname.sub(/.xml$/, '.html'); html.untaint
        File.open(html, File::CREAT|File::WRONLY|File::TRUNC) {|f|
          f.puts po.join("\n").gsub(%r!src="/images/!, 'src="images/').gsub(%r!/css/main!, 'css/main').gsub(%r!href="/!, 'href="http://www.gentoo.org/')
        }
        # Return html file name
        return html
      else
        # Unlikely, but we got no error and no file. Uh?
        return ""
      end
    }
  end

  def to_H(group="")
    # Output header line
    r = $ColHeaders.collect {|t| t.gsub(/\{langfrom\}/,"#{@langfrom.upcase}").gsub(/\{langto\}/,"#{@langto.upcase}")}
    unless (group||"") == "" then
      # Use group name in first column
      r[0] = group     #  [group] + $ColHeaders[1..-1].collect { ""}
    end
    "<tr><th>" + r.join('</th><th>') + "</th></tr>" 
  end

  def getCVSdata
    @documents.getCVSdata
  end

  def select(filespec)
    regxp = Regexp.new(filespec.gsub('.','\.').gsub('*','.*').gsub('?','.'))
    s = @documents.find_all{|k,v| v.localfilename =~ regxp}
    s if s.length > 0
  end
  
  def findNick(n)
    return n if traducteurs[n] # Got one exact match
    # Be `clever´ and use regexp matching if an exact match cannot be found
    a = []
    x = Regexp.new(n)
    traducteurs.each { |t,m| a << t if t =~ x }
    raise "Cannot identify #{n} amongst #{a.join(', ')}" if a.length > 1
    raise "Unknown nick #{n}" if a.length < 1
    a[0]
  end
  
  def genTargets
    @targetList = documents.generateTargets
  end

  def writePage
    # Write .xml file
    @genxml = ["#{$Base}/work/#{@genfile}.xml", "#{$Base}/work/#{@genfile}-0.xml"]
    @genxml.untaint
    @genxml[0].untaint
    @genxml[1].untaint
    @genhtml = []
    File.open(@genxml[0], File::CREAT|File::WRONLY|File::TRUNC) { |f|
      f.puts documents.to_s
    }
    File.open(@genxml[1], File::CREAT|File::WRONLY|File::TRUNC) { |f|
      f.puts documents.to_s(true)
    }
    if @dohtml then
      @genhtml << xml2html(@genxml[0])
      @genhtml << xml2html(@genxml[1])
      tlog("Generated #{@genhtml.join(' ')}")
    end
  end

  def uploadFiles
    tlog("Upload request")
    # If @genhtml contains anything, upload list of targets and our newly generated page
    if @genhtml != "" then
      flst = "#{@xmlfilename} #{@genxml.join(' ')} #{@genhtml.join(' ')} #{@targetList.join(' ')}".squeeze(" ")
      stdo, stdr = runrun("scp -Cpq #{flst}  #{@wwwdev}", @log)
      raise "Could not upload files: #{stdr.join("\n")}" if stdr.length > 0
      flst.split
    else
      raise "#{@genfile}.html  has not been generated. File upload cancelled."
    end
  end
  
  def doUpload
    # Refresh and fill up CVS data
    @documents.getCVSdata(@documents)
    genTargets
    writePage
    uploadFiles # Return array of upload filenames
  end
  
  def doAction(action)
    # Turn hash into an OpenStruct (allows to pass an action as a hash which is easier)
    action = OpenStruct.new(action) if action.respond_to?('[]')
    # Execute requested action
    @mutex.synchronize do
      tlog("doAction( #{action.inspect} )")
      case action.action
        when "LIST"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # Get their cvs data
            @documents.getCVSdata(docs)
            # Format output
            otxt = String.new
            docs = docs.sort {|a,b| a[1].localfilename <=> b[1].localfilename}
            otxt << "\n" << docs[0][1].listH << "\n"
            docs.each {|d| otxt << "#{d[1].list}\n"}
            otxt
          end
        when "SYNC"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # Get their cvs data
            @documents.getCVSdata(docs)
            # Check if sync value is not greater than current English revision
            docs.each {|n,d| raise "Cannot sync #{d.localfilename} beyond current revision #{d.rev}" if action.rev > d.rev} if action.rev > "0.0" and !action.rev.nil?
            # Sync values
            docs.each {|n,d| d.sync = action.rev}
            # Write .xml file
            saveXML
          end
          nil
        when "DIFF"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # Get their cvs data
            @documents.getCVSdata(docs)
            # Get CVS log & diff
            logdif = []
            docs.each do |n,d| 
                        rv, lg, df = d.getCVSdiff(d.sync, d.rev)
                        if rv then
                          # Output log formatted for cmd line
                          t = "Log history of #{d.localfilename}"
                          logdif << "\n\n#{t}\n"
                          logdif << "#{t.gsub(/./,'-')}\n"
                          
                          lg.each {|logentry|
                            logdif << logentry.join("\n") << "\n\n"
                          }
                          
                          # Output diff formatted for cmd line
                          t = "Differences from revision #{rv[0]} to #{rv[1]}"
                          logdif << "#{t}\n"
                          logdif << "#{t.gsub(/./,'-')}\n"
                          
                          df.each {|blk|
                            logdif << "\n@@@___Line #{blk[0][0]}___@@@\n"
                            blk[1..-1].each {|txtblk|
                            case txtblk[0]
                              when "=" then logdif << "  #{txtblk[1].join("\n  ")}\n"
                              when "+" then logdif << "+ #{txtblk[1].join("\n+ ")}\n"
                              when "-" then logdif << "- #{txtblk[1].join("\n- ")}\n"
                              when "~" then logdif << "- #{txtblk[1].join("\n- ")}\n+ #{txtblk[2].join("\n+ ")}\n"
                            end
                            }
                          }
                          logdif << "=" * 80 + "\n"
                        end
            end
            logdif
          end
        when "REFRESH"
          # Just read CVS data with force option to _force_ reading _all_ revisions/dates
          @documents.getCVSdata(@documents, true)
          nil
        when "UPLOAD"
          lst = doUpload
          # Return output string for cmd line version
          "Uploaded #{lst.collect{|l|File.basename(l)}.join("\n\t ")}\n"
        when "LOCK"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # Check nick is listed in <translators>
            nick = findNick(action.nick)
            # Set lock
            docs.each {|n,d| d.lock = nick}
            # Write .xml file
            saveXML
          end
          nil
        when "RELEASE"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # Check nick is listed in <translators>
            nick = findNick(action.nick)
            # Release lock, don't bother if unlocked
            docs.each {|n,d| d.lock = nil if d.lock == nick}
            # Write .xml file
            saveXML
          end
          nil
        when "GIVE"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # Check nick is listed in <translators>
            nick = findNick(action.nick)
            # Set target/nick
            docs.each {|n,d| d.target, d.nick = action.rev, nick}
            # Write .xml file
            saveXML
          end
          nil
        when "FREE"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # Reset target/nick
            docs.each {|n,d| d.target, d.nick = "0", ""}
            # Write .xml file
            saveXML
          end
          nil
        when "GROUP"
          # Get list of docs that match filespec
          if docs = select(action.filespec) then
            # (Re)set group
            docs.each {|n,d| d.group = action.group}
            # Write .xml file
            saveXML
          end
          nil
        else
          raise "Unsupported action. Sorry."
      end
    end
  end
end


#  ^^^^
#  Main ;-)
#  ____

if $0==__FILE__ then
 
  # Parse command-line
  opts = TradsOptionParser.parse(ARGV)
  
  if opts.client then
    # Connect to the daemon
    
    # Start service on client needed to allow SSH tunneling
    if opts.rport then
      DRb.start_service("druby://localhost:#{opts.rport}")
    else
      DRb.start_service()
    end
    tt = DRbObject.new(nil, "druby://localhost:#{opts.port}")

    tt.tlog("#{`id -un`.chomp} connected (#{`uname -snrmpo`.chomp})")
  else
    gorg = `which gorg`.chomp
    raise "AAAaaarrgh : I need gorg to do my job" unless gorg != "" and IO.read(gorg) =~ /--filter/

    # Create a new instance
    # Conf file is this script file name with .xml extension in xml dir
    xml = "#{$Base}/xml/trads.xml"
    fxml = File.new(xml)
    # Try to get exclusive use of file
    raise "File is currently in use\n\nCannot acquire exclusive use of #{xml}\n" unless fxml.flock(File::LOCK_EX|File::LOCK_NB)
    # Create a new instance
    tt = TTrads.new(xml)
  end
  
  if opts.daemon then
    # Publish instance
    $SAFE=1
    tt.tlog("Going into daemon mode on port #{opts.port}")
    puts "Starting daemon on port #{opts.port}"
    DRb.start_service("druby://#{opts.server}:#{opts.port}", tt)
    # For some reason, I need to lock the file again
    raise "Cannot acquire(2) exclusive use of #{xml}" unless fxml.flock(File::LOCK_EX|File::LOCK_NB)
    trap("INT"){ puts "End of service";exit }
    DRb.thread.join
  elsif opts.web then
    # Start web server
    web = TWeb.new(opts.webport, tt)
    web.startWeb
  else
    # Client or stand-alone
    if opts.actions.length > 0 then
      opts.actions.each {|a|
        otxt = tt.doAction(a)
        print otxt if otxt
      }
    else
      # No action, update and upload page
      print tt.doAction({'action'=>'UPLOAD'})
    end
  end
end
