# Simple Revision Number class (2.34 e.g.)
# Strings should be like \d+.\d+, 0 will become 0.0
# Comparisons and #succ & #prec have been defined as well as minus operator

class RevNum
  include Comparable
  attr_reader :maj, :min

  def initialize(s=nil)
    @@limit = 999
    @maj, @min = nil,nil
    raise "Illegal revision number" unless (s||"")=="" or (s||"")=="0" or s =~ /^(\d+).(\d+)$/
    @maj, @min = 0, 0 if (s||"")=="0"
    @maj, @min = $1.to_i, $2.to_i unless (s||"")==""
    self
  end
  
  def to_s
    if @maj.nil? then "" else "#{@maj}.#{@min}" end
  end
  
  def nil?
    @maj.nil?
  end
  
  def inspect
    to_s unless @maj.nil?
  end
  
  def <=>(other)
    other=RevNum.new(other.to_s) if other.class != self.class
    if ((self.maj||-1) <=> (other.maj||-1)) == 0
      (self.min||-1) <=> (other.min||-1)
    else
      (self.maj||-1) <=> (other.maj||-1)
    end
  end

  def -(other)
    other=RevNum.new(other.to_s) if other.class != self.class
    return 0   if self.nil? and other.nil?
    return nil if self.nil?  or other.nil?
    (self.maj-other.maj)*(@@limit+1) + self.min-other.min
  end
  
  def succ!
    return nil if nil?
    @min += 1
    @maj, @min = @maj+1, 0 if @min > @@limit
    self
  end
  
  def succ
    self.clone.succ!
  end

  def prec!
    return nil if nil?
    @min -= 1
    @maj, @min = @maj-1, @@limit if @min < 0
    @maj = 0 if @maj < 0
    self
  end
  
  def prec
    self.clone.prec!
  end
end
